"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAssetStatus = exports.createAsset = exports.getAssets = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getAssets = async (req, res) => {
    try {
        const { companyId } = req.user;
        const assets = await prisma_1.default.asset.findMany({
            where: { companyId },
            include: {
                assignedTo: { select: { firstName: true, lastName: true, email: true } }
            },
            orderBy: { createdAt: 'desc' }
        });
        res.json(assets);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch assets' });
    }
};
exports.getAssets = getAssets;
const createAsset = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { name, category, serialNumber, assignedToId } = req.body;
        if (!name || !category) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const asset = await prisma_1.default.asset.create({
            data: {
                companyId,
                name,
                category,
                serialNumber,
                assignedToId: assignedToId || null,
                status: assignedToId ? 'ASSIGNED' : 'AVAILABLE'
            },
            include: {
                assignedTo: { select: { firstName: true, lastName: true } }
            }
        });
        res.status(201).json(asset);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to create asset' });
    }
};
exports.createAsset = createAsset;
const updateAssetStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, assignedToId } = req.body;
        const { companyId } = req.user;
        const asset = await prisma_1.default.asset.update({
            where: { id, companyId },
            data: {
                status,
                assignedToId: assignedToId !== undefined ? assignedToId : undefined
            },
            include: {
                assignedTo: { select: { firstName: true, lastName: true } }
            }
        });
        res.json(asset);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to update asset' });
    }
};
exports.updateAssetStatus = updateAssetStatus;
//# sourceMappingURL=assetController.js.map