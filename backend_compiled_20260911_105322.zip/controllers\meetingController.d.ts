import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getMeetings: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createMeeting: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=meetingController.d.ts.map