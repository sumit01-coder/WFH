"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTimesheetEntry = exports.getTimesheets = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getTimesheets = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        let whereClause = { companyId };
        if (!['HR', 'MANAGER', 'COMPANY_ADMIN', 'SUPER_ADMIN'].includes(role)) {
            whereClause.userId = userId;
        }
        const timesheets = await prisma_1.default.timesheetEntry.findMany({
            where: whereClause,
            include: {
                user: { select: { firstName: true, lastName: true, email: true } },
                project: { select: { name: true } },
                task: { select: { title: true } }
            },
            orderBy: { date: 'desc' }
        });
        res.json(timesheets);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch timesheets' });
    }
};
exports.getTimesheets = getTimesheets;
const createTimesheetEntry = async (req, res) => {
    try {
        const { companyId, userId } = req.user;
        const { projectId, taskId, date, hours, description } = req.body;
        if (!projectId || !date || !hours) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const entry = await prisma_1.default.timesheetEntry.create({
            data: {
                companyId,
                userId,
                projectId,
                taskId: taskId || null,
                date: new Date(date),
                hours: Number(hours),
                description
            },
            include: {
                user: { select: { firstName: true, lastName: true } },
                project: { select: { name: true } },
                task: { select: { title: true } }
            }
        });
        res.status(201).json(entry);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to create timesheet entry' });
    }
};
exports.createTimesheetEntry = createTimesheetEntry;
//# sourceMappingURL=timesheetController.js.map