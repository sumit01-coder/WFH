import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getPerformanceRecords: (req: AuthRequest, res: Response) => Promise<void>;
export declare const generatePerformanceRecord: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=performanceController.d.ts.map