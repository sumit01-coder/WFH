"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateBulkLeaveBalances = exports.updateLeaveBalance = exports.getLeaveBalances = exports.updateLeaveStatus = exports.getLeaveRequests = exports.createLeaveRequest = void 0;
const rbac_1 = require("../utils/rbac");
const prisma_1 = __importDefault(require("../utils/prisma"));
const createLeaveRequest = async (req, res) => {
    try {
        const { companyId, userId } = req.user;
        const { leaveType, startDate, endDate, reason } = req.body;
        if (!leaveType || !startDate || !endDate) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const leaveRequest = await prisma_1.default.leaveRequest.create({
            data: {
                companyId,
                userId,
                leaveType,
                startDate: new Date(startDate),
                endDate: new Date(endDate),
                reason
            },
            include: {
                user: { select: { firstName: true, lastName: true, managerId: true } }
            }
        });
        // Notify HR and the employee's manager
        const hrAndManagers = await prisma_1.default.user.findMany({
            where: {
                companyId,
                isDeleted: false,
                OR: [
                    { userRoles: { some: { role: { name: { in: ['HR', 'COMPANY_ADMIN'] } } } } },
                    { id: leaveRequest.user.managerId || '' }
                ]
            },
            select: { id: true }
        });
        const applicantName = `${leaveRequest.user.firstName} ${leaveRequest.user.lastName}`;
        await prisma_1.default.notification.createMany({
            data: hrAndManagers
                .filter(u => u.id !== userId)
                .map(u => ({
                companyId,
                userId: u.id,
                type: 'LEAVE',
                title: 'New Leave Request',
                body: `${applicantName} has submitted a ${leaveType} leave request.`,
                resourceType: 'LEAVE',
                resourceId: leaveRequest.id
            }))
        });
        res.status(201).json(leaveRequest);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error creating leave request' });
    }
};
exports.createLeaveRequest = createLeaveRequest;
const getLeaveRequests = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        const { date, status } = req.query;
        let whereClause = { companyId };
        if (date) {
            const d = new Date(String(date));
            const startOfDay = new Date(d.setUTCHours(0, 0, 0, 0));
            whereClause.startDate = { lte: startOfDay };
            whereClause.endDate = { gte: startOfDay };
        }
        if (status) {
            whereClause.status = status;
        }
        // If not a manager/HR/admin, only show their own leaves
        if (!['HR', 'MANAGER', 'COMPANY_ADMIN', 'SUPER_ADMIN'].includes(role)) {
            whereClause.userId = userId;
        }
        const leaveRequests = await prisma_1.default.leaveRequest.findMany({
            where: whereClause,
            include: {
                user: { select: { firstName: true, lastName: true, email: true } },
                reviewedBy: { select: { firstName: true, lastName: true } }
            },
            orderBy: { createdAt: 'desc' }
        });
        res.json(leaveRequests);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error fetching leave requests' });
    }
};
exports.getLeaveRequests = getLeaveRequests;
const updateLeaveStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, reviewRemarks } = req.body;
        const { companyId, userId } = req.user;
        if (!['APPROVED', 'REJECTED'].includes(status)) {
            return res.status(400).json({ error: 'Invalid status' });
        }
        const leaveRequest = await prisma_1.default.leaveRequest.findFirst({
            where: { id, companyId }
        });
        if (!leaveRequest) {
            return res.status(404).json({ error: 'Leave request not found' });
        }
        const canAssign = await (0, rbac_1.canModifyUser)(req.user.role, leaveRequest.userId, false);
        if (!canAssign) {
            return res.status(403).json({ error: 'You do not have permission to approve/reject leaves for this user.' });
        }
        const updatedLeave = await prisma_1.default.leaveRequest.update({
            where: { id },
            data: {
                status,
                reviewRemarks,
                reviewedById: userId,
                reviewedAt: new Date()
            },
            include: {
                user: { select: { firstName: true, lastName: true, email: true } },
                reviewedBy: { select: { firstName: true, lastName: true } }
            }
        });
        if (status === 'APPROVED') {
            const days = Math.ceil((new Date(updatedLeave.endDate).getTime() - new Date(updatedLeave.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1;
            const balance = await prisma_1.default.leaveBalance.findUnique({
                where: { userId_leaveType: { userId: updatedLeave.userId, leaveType: updatedLeave.leaveType } }
            });
            if (balance) {
                await prisma_1.default.leaveBalance.update({
                    where: { id: balance.id },
                    data: { usedDays: balance.usedDays + days }
                });
            }
            else {
                await prisma_1.default.leaveBalance.create({
                    data: {
                        companyId: updatedLeave.companyId,
                        userId: updatedLeave.userId,
                        leaveType: updatedLeave.leaveType,
                        totalDays: 15,
                        usedDays: days
                    }
                });
            }
        }
        // Notify the employee about the decision
        await prisma_1.default.notification.create({
            data: {
                companyId,
                userId: updatedLeave.userId,
                type: 'LEAVE',
                title: `Leave Request ${status === 'APPROVED' ? 'Approved ✅' : 'Rejected ❌'}`,
                body: `Your ${updatedLeave.leaveType} leave request has been ${status.toLowerCase()}.${reviewRemarks ? ` Remarks: ${reviewRemarks}` : ''}`,
                resourceType: 'LEAVE',
                resourceId: updatedLeave.id
            }
        });
        res.json(updatedLeave);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error updating leave request' });
    }
};
exports.updateLeaveStatus = updateLeaveStatus;
const getLeaveBalances = async (req, res) => {
    try {
        const { userId, role } = req.user;
        const targetUserId = req.query.userId || userId;
        if (targetUserId !== userId) {
            if (!['HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'].includes(role)) {
                return res.status(403).json({ error: 'You do not have permission to view this user\'s leave balances.' });
            }
        }
        const balances = await prisma_1.default.leaveBalance.findMany({
            where: { userId: targetUserId }
        });
        // If no balances exist, return defaults
        if (balances.length === 0) {
            return res.json([
                { leaveType: 'VACATION', totalDays: 15, usedDays: 0 },
                { leaveType: 'SICK', totalDays: 10, usedDays: 0 },
                { leaveType: 'PERSONAL', totalDays: 5, usedDays: 0 }
            ]);
        }
        res.json(balances);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch leave balances' });
    }
};
exports.getLeaveBalances = getLeaveBalances;
const updateLeaveBalance = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { userId, leaveType, totalDays, usedDays } = req.body;
        if (!userId || !leaveType || totalDays === undefined || usedDays === undefined) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const balance = await prisma_1.default.leaveBalance.upsert({
            where: {
                userId_leaveType: {
                    userId,
                    leaveType
                }
            },
            update: {
                totalDays: Number(totalDays),
                usedDays: Number(usedDays)
            },
            create: {
                userId,
                companyId,
                leaveType,
                totalDays: Number(totalDays),
                usedDays: Number(usedDays)
            }
        });
        res.json(balance);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error updating leave balance' });
    }
};
exports.updateLeaveBalance = updateLeaveBalance;
const updateBulkLeaveBalances = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { leaveType, totalDays, resetUsedDays } = req.body;
        if (!leaveType || totalDays === undefined) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        // Get all users in the company
        const users = await prisma_1.default.user.findMany({
            where: { companyId },
            select: { id: true }
        });
        // We can't do updateMany for upserts easily in Prisma if records don't exist,
        // so we iterate or use a transaction.
        const upsertPromises = users.map(u => {
            const updateData = { totalDays: Number(totalDays) };
            if (resetUsedDays) {
                updateData.usedDays = 0;
            }
            return prisma_1.default.leaveBalance.upsert({
                where: {
                    userId_leaveType: {
                        userId: u.id,
                        leaveType
                    }
                },
                update: updateData,
                create: {
                    userId: u.id,
                    companyId,
                    leaveType,
                    totalDays: Number(totalDays),
                    usedDays: 0
                }
            });
        });
        await prisma_1.default.$transaction(upsertPromises);
        res.json({ success: true, message: `Updated ${leaveType} balance for ${users.length} employees.` });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error bulk updating leave balances' });
    }
};
exports.updateBulkLeaveBalances = updateBulkLeaveBalances;
//# sourceMappingURL=leaveController.js.map