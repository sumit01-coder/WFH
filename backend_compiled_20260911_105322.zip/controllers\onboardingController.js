"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateOnboardingTaskStatus = exports.createOnboardingTask = exports.getOnboardingTasks = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getOnboardingTasks = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        let whereClause = { companyId };
        if (!['HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'].includes(role)) {
            whereClause.userId = userId;
        }
        const tasks = await prisma_1.default.onboardingTask.findMany({
            where: whereClause,
            include: {
                user: { select: { firstName: true, lastName: true, email: true } }
            },
            orderBy: { createdAt: 'asc' }
        });
        res.json(tasks);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch onboarding tasks' });
    }
};
exports.getOnboardingTasks = getOnboardingTasks;
const createOnboardingTask = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { employeeId, title, description } = req.body;
        if (!employeeId || !title) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const task = await prisma_1.default.onboardingTask.create({
            data: {
                companyId,
                userId: employeeId,
                title,
                description
            },
            include: {
                user: { select: { firstName: true, lastName: true } }
            }
        });
        res.status(201).json(task);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to create onboarding task' });
    }
};
exports.createOnboardingTask = createOnboardingTask;
const updateOnboardingTaskStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { isCompleted } = req.body;
        const { companyId } = req.user;
        const task = await prisma_1.default.onboardingTask.update({
            where: { id, companyId },
            data: { isCompleted }
        });
        res.json(task);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to update task status' });
    }
};
exports.updateOnboardingTaskStatus = updateOnboardingTaskStatus;
//# sourceMappingURL=onboardingController.js.map