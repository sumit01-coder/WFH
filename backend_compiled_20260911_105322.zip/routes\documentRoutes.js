"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const documentController_1 = require("../controllers/documentController");
const multer_1 = __importDefault(require("multer"));
const fs_1 = __importDefault(require("fs"));
const router = (0, express_1.Router)();
// Configure multer for file uploads
const storage = multer_1.default.diskStorage({
    destination: function (req, file, cb) {
        const dir = 'uploads/documents';
        if (!fs_1.default.existsSync(dir)) {
            fs_1.default.mkdirSync(dir, { recursive: true });
        }
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + file.originalname);
    }
});
const upload = (0, multer_1.default)({ storage: storage });
// Everyone can view documents
router.get('/', requireAuth_1.requireAuth, documentController_1.getDocuments);
// Everyone can download documents
router.get('/:id/download', requireAuth_1.requireAuth, documentController_1.downloadDocument);
// Only Managers, HR, Company Admins can upload
router.post('/upload', requireAuth_1.requireAuth, (0, requireRole_1.requireRole)('HR', 'MANAGER', 'COMPANY_ADMIN', 'SUPER_ADMIN'), upload.single('document'), documentController_1.uploadDocument);
exports.default = router;
//# sourceMappingURL=documentRoutes.js.map