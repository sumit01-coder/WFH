"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const requireAuth_1 = require("../middleware/requireAuth");
const monitorController_1 = require("../controllers/monitorController");
const router = (0, express_1.Router)();
const upload = (0, multer_1.default)({ storage: multer_1.default.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
router.post('/activity', requireAuth_1.requireAuth, monitorController_1.logActivity);
router.post('/screenshot', requireAuth_1.requireAuth, upload.single('screenshot'), monitorController_1.uploadScreenshot);
router.get('/activity', requireAuth_1.requireAuth, monitorController_1.getActivityLogs);
router.get('/screenshots', requireAuth_1.requireAuth, monitorController_1.getScreenshots);
exports.default = router;
//# sourceMappingURL=monitorRoutes.js.map