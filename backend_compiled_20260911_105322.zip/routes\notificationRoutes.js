"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const requireAuth_1 = require("../middleware/requireAuth");
const notificationController_1 = require("../controllers/notificationController");
const router = (0, express_1.Router)();
router.get('/', requireAuth_1.requireAuth, notificationController_1.getNotifications);
router.get('/unread-count', requireAuth_1.requireAuth, notificationController_1.getUnreadCount);
router.patch('/:id/read', requireAuth_1.requireAuth, notificationController_1.markAsRead);
router.post('/read-all', requireAuth_1.requireAuth, notificationController_1.markAllAsRead);
exports.default = router;
//# sourceMappingURL=notificationRoutes.js.map