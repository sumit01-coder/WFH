"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const workReportController_1 = require("../controllers/workReportController");
const router = (0, express_1.Router)();
router.get('/', workReportController_1.getWorkReports);
router.post('/', workReportController_1.submitWorkReport);
exports.default = router;
//# sourceMappingURL=workReportRoutes.js.map