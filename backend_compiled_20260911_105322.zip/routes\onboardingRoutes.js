"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const onboardingController_1 = require("../controllers/onboardingController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', onboardingController_1.getOnboardingTasks);
router.post('/', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'), onboardingController_1.createOnboardingTask);
router.put('/:id', onboardingController_1.updateOnboardingTaskStatus);
exports.default = router;
//# sourceMappingURL=onboardingRoutes.js.map