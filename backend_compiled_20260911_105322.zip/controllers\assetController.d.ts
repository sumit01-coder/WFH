import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getAssets: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createAsset: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateAssetStatus: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=assetController.d.ts.map