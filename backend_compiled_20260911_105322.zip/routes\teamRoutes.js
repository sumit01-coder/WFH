"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const teamController_1 = require("../controllers/teamController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', teamController_1.getTeams);
router.post('/', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'), teamController_1.createTeam);
router.put('/:id', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'), teamController_1.updateTeam);
router.delete('/:id', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'), teamController_1.deleteTeam);
exports.default = router;
//# sourceMappingURL=teamRoutes.js.map