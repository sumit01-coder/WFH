"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const assetController_1 = require("../controllers/assetController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.use((0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'));
router.get('/', assetController_1.getAssets);
router.post('/', assetController_1.createAsset);
router.put('/:id/status', assetController_1.updateAssetStatus);
exports.default = router;
//# sourceMappingURL=assetRoutes.js.map