"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const meetingController_1 = require("../controllers/meetingController");
const requireAuth_1 = require("../middleware/requireAuth");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', meetingController_1.getMeetings);
router.post('/', meetingController_1.createMeeting);
exports.default = router;
//# sourceMappingURL=meetingRoutes.js.map