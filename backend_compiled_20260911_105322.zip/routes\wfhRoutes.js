"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const wfhController_1 = require("../controllers/wfhController");
const requireAuth_1 = require("../middleware/requireAuth");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', wfhController_1.getWfhRequests);
router.post('/', wfhController_1.createWfhRequest);
router.patch('/:id/status', wfhController_1.updateWfhStatus);
exports.default = router;
//# sourceMappingURL=wfhRoutes.js.map