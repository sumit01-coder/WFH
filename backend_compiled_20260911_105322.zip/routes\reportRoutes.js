"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const reportController_1 = require("../controllers/reportController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', reportController_1.getWorkReports);
router.post('/', reportController_1.submitWorkReport);
router.put('/:id/review', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'), reportController_1.reviewWorkReport);
exports.default = router;
//# sourceMappingURL=reportRoutes.js.map