"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateOffboardingTaskStatus = exports.createOffboardingTask = exports.getOffboardingTasks = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getOffboardingTasks = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        let whereClause = { companyId };
        if (!['HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'].includes(role)) {
            whereClause.userId = userId;
        }
        const tasks = await prisma_1.default.offboardingTask.findMany({
            where: whereClause,
            include: {
                user: { select: { firstName: true, lastName: true, email: true } }
            },
            orderBy: { createdAt: 'asc' }
        });
        res.json(tasks);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch offboarding tasks' });
    }
};
exports.getOffboardingTasks = getOffboardingTasks;
const createOffboardingTask = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { employeeId, title, description } = req.body;
        if (!employeeId || !title) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const task = await prisma_1.default.offboardingTask.create({
            data: {
                companyId,
                userId: employeeId,
                title,
                description
            },
            include: {
                user: { select: { firstName: true, lastName: true } }
            }
        });
        res.status(201).json(task);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to create offboarding task' });
    }
};
exports.createOffboardingTask = createOffboardingTask;
const updateOffboardingTaskStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { isCompleted } = req.body;
        const { companyId } = req.user;
        const task = await prisma_1.default.offboardingTask.update({
            where: { id, companyId },
            data: { isCompleted }
        });
        res.json(task);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to update task status' });
    }
};
exports.updateOffboardingTaskStatus = updateOffboardingTaskStatus;
//# sourceMappingURL=offboardingController.js.map