"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const projectController_1 = require("../controllers/projectController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', projectController_1.getProjects);
router.post('/', (0, requireRole_1.requireRole)('SUPER_ADMIN', 'COMPANY_ADMIN', 'HR', 'MANAGER'), projectController_1.createProject);
router.put('/:id', (0, requireRole_1.requireRole)('SUPER_ADMIN', 'COMPANY_ADMIN', 'HR', 'MANAGER'), projectController_1.updateProject);
exports.default = router;
//# sourceMappingURL=projectRoutes.js.map