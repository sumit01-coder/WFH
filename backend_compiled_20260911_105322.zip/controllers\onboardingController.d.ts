import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getOnboardingTasks: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createOnboardingTask: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateOnboardingTaskStatus: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=onboardingController.d.ts.map