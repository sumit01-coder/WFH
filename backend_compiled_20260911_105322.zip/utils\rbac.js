"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.canModifyUser = exports.getUserMaxRank = exports.getRoleRank = exports.ROLE_RANKS = void 0;
const prisma_1 = __importDefault(require("./prisma"));
exports.ROLE_RANKS = {
    'SUPER_ADMIN': 5,
    'COMPANY_ADMIN': 4,
    'HR': 3,
    'MANAGER': 2,
    'EMPLOYEE': 1,
};
const getRoleRank = (roleName) => {
    return exports.ROLE_RANKS[roleName] || 0;
};
exports.getRoleRank = getRoleRank;
/**
 * Gets the highest rank of a given user based on their UserRoles.
 * @param userId The ID of the user to check
 * @returns The highest numeric rank of the user's roles
 */
const getUserMaxRank = async (userId) => {
    const userRoles = await prisma_1.default.userRole.findMany({
        where: { userId },
        include: { role: true },
    });
    if (!userRoles || userRoles.length === 0)
        return 0;
    return Math.max(...userRoles.map((ur) => (0, exports.getRoleRank)(ur.role.name)));
};
exports.getUserMaxRank = getUserMaxRank;
/**
 * Checks if the requester has permission to modify/assign the target user based on strict vertical hierarchy.
 * @param requesterRole The role name of the user performing the action (e.g., 'HR', 'COMPANY_ADMIN')
 * @param targetUserId The ID of the user being acted upon
 * @param allowEqual If true, users of equal rank can modify each other (default: false)
 * @returns true if permitted, false if the target user has an equal or higher rank
 */
const canModifyUser = async (requesterRole, targetUserId, allowEqual = false) => {
    const requesterRank = (0, exports.getRoleRank)(requesterRole);
    const targetRank = await (0, exports.getUserMaxRank)(targetUserId);
    return allowEqual ? requesterRank >= targetRank : requesterRank > targetRank;
};
exports.canModifyUser = canModifyUser;
//# sourceMappingURL=rbac.js.map