import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getAttendance: (req: AuthRequest, res: Response) => Promise<void>;
export declare const checkIn: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const checkOut: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const startLunchBreak: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const endLunchBreak: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=attendanceController.d.ts.map