"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.submitWorkReport = exports.getWorkReports = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getWorkReports = async (req, res) => {
    try {
        const { companyId, userId, date } = req.query;
        const whereClause = { companyId: String(companyId) };
        if (userId)
            whereClause.userId = String(userId);
        if (date)
            whereClause.date = new Date(String(date));
        const reports = await prisma_1.default.workReport.findMany({
            where: whereClause,
            include: { user: { select: { firstName: true, lastName: true } } },
            orderBy: { date: 'desc' }
        });
        res.json(reports);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching work reports' });
    }
};
exports.getWorkReports = getWorkReports;
const submitWorkReport = async (req, res) => {
    try {
        const { companyId, userId, date, completedWork, wip, blockers, tomorrowPlan, hoursWorked } = req.body;
        const reportDate = new Date(date);
        const report = await prisma_1.default.workReport.create({
            data: {
                companyId, userId, date: reportDate, completedWork, wip, blockers, tomorrowPlan, hoursWorked, status: 'SUBMITTED'
            }
        });
        res.status(201).json(report);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error submitting work report' });
    }
};
exports.submitWorkReport = submitWorkReport;
//# sourceMappingURL=workReportController.js.map