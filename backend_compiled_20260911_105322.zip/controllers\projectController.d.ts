import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getProjects: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createProject: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateProject: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=projectController.d.ts.map