import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const createLeaveRequest: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getLeaveRequests: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateLeaveStatus: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getLeaveBalances: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateLeaveBalance: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateBulkLeaveBalances: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=leaveController.d.ts.map