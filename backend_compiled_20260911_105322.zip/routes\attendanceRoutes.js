"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const requireAuth_1 = require("../middleware/requireAuth");
const attendanceController_1 = require("../controllers/attendanceController");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', attendanceController_1.getAttendance);
router.post('/checkin', attendanceController_1.checkIn);
const multer_1 = __importDefault(require("multer"));
const fs_1 = __importDefault(require("fs"));
const storage = multer_1.default.diskStorage({
    destination: function (req, file, cb) {
        const dir = 'uploads/worklogs';
        if (!fs_1.default.existsSync(dir)) {
            fs_1.default.mkdirSync(dir, { recursive: true });
        }
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + file.originalname);
    }
});
const upload = (0, multer_1.default)({ storage: storage });
router.patch('/:id/checkout', upload.single('worklog_attachment'), attendanceController_1.checkOut);
// Lunch break routes
router.post('/:id/break/start', attendanceController_1.startLunchBreak);
router.patch('/break/:breakId/end', attendanceController_1.endLunchBreak);
exports.default = router;
//# sourceMappingURL=attendanceRoutes.js.map