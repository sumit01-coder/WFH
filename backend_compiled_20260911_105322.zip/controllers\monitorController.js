"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getScreenshots = exports.getActivityLogs = exports.uploadScreenshot = exports.logActivity = void 0;
const client_1 = require("@prisma/client");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const prisma = new client_1.PrismaClient();
// POST /api/monitor/activity — receive batch of activity logs from desktop app
const logActivity = async (req, res) => {
    try {
        const userId = req.user.userId;
        const companyId = req.user.companyId;
        const { logs } = req.body;
        if (!logs || !Array.isArray(logs) || logs.length === 0) {
            res.status(400).json({ error: 'No logs provided' });
            return;
        }
        await prisma.activityLog.createMany({
            data: logs.map((l) => ({
                companyId,
                userId,
                appName: l.appName,
                windowTitle: l.windowTitle,
                durationSec: l.durationSec,
                isIdle: l.isIdle,
                recordedAt: new Date(l.recordedAt),
            })),
        });
        res.json({ success: true });
    }
    catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to save activity logs' });
    }
};
exports.logActivity = logActivity;
// POST /api/monitor/screenshot — upload a screenshot
const uploadScreenshot = async (req, res) => {
    try {
        const userId = req.user.userId;
        const companyId = req.user.companyId;
        if (!req.file) {
            res.status(400).json({ error: 'No screenshot file provided' });
            return;
        }
        const screenshotDir = path_1.default.join(process.cwd(), 'uploads', 'screenshots', companyId, userId);
        fs_1.default.mkdirSync(screenshotDir, { recursive: true });
        const filename = `${Date.now()}.jpg`;
        const filePath = path_1.default.join(screenshotDir, filename);
        fs_1.default.writeFileSync(filePath, req.file.buffer);
        await prisma.desktopScreenshot.create({
            data: {
                companyId,
                userId,
                filePath: `/uploads/screenshots/${companyId}/${userId}/${filename}`,
                takenAt: new Date(),
            },
        });
        res.json({ success: true });
    }
    catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to save screenshot' });
    }
};
exports.uploadScreenshot = uploadScreenshot;
// GET /api/monitor/activity?userId=&date= — HR/Manager view activity logs
const getActivityLogs = async (req, res) => {
    try {
        const companyId = req.user.companyId;
        const { userId, date } = req.query;
        const targetDate = date ? new Date(date) : new Date();
        const start = new Date(targetDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(targetDate);
        end.setHours(23, 59, 59, 999);
        const logs = await prisma.activityLog.findMany({
            where: {
                companyId,
                ...(userId ? { userId: userId } : {}),
                recordedAt: { gte: start, lte: end },
            },
            include: {
                user: { select: { id: true, firstName: true, lastName: true, photoUrl: true } },
            },
            orderBy: { recordedAt: 'desc' },
        });
        // Aggregate by app
        const appSummary = {};
        for (const log of logs) {
            if (!log.isIdle) {
                appSummary[log.appName] = (appSummary[log.appName] || 0) + log.durationSec;
            }
        }
        res.json({ logs, appSummary });
    }
    catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to fetch activity logs' });
    }
};
exports.getActivityLogs = getActivityLogs;
// GET /api/monitor/screenshots?userId=&date= — HR/Manager view screenshots
const getScreenshots = async (req, res) => {
    try {
        const companyId = req.user.companyId;
        const { userId, date } = req.query;
        const targetDate = date ? new Date(date) : new Date();
        const start = new Date(targetDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(targetDate);
        end.setHours(23, 59, 59, 999);
        const screenshots = await prisma.desktopScreenshot.findMany({
            where: {
                companyId,
                ...(userId ? { userId: userId } : {}),
                takenAt: { gte: start, lte: end },
            },
            include: {
                user: { select: { id: true, firstName: true, lastName: true } },
            },
            orderBy: { takenAt: 'desc' },
        });
        res.json({ screenshots });
    }
    catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to fetch screenshots' });
    }
};
exports.getScreenshots = getScreenshots;
//# sourceMappingURL=monitorController.js.map