import { Request, Response } from 'express';
export declare const getAssignments: (req: Request, res: Response) => Promise<void>;
export declare const createAssignment: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=assignmentController.d.ts.map