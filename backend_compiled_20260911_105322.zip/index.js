"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config(); // Must be called FIRST before any other imports read process.env
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const authRoutes_1 = __importDefault(require("./routes/authRoutes"));
const companyRoutes_1 = __importDefault(require("./routes/companyRoutes"));
const employeeRoutes_1 = __importDefault(require("./routes/employeeRoutes"));
const departmentRoutes_1 = __importDefault(require("./routes/departmentRoutes"));
const teamRoutes_1 = __importDefault(require("./routes/teamRoutes"));
const projectRoutes_1 = __importDefault(require("./routes/projectRoutes"));
const taskRoutes_1 = __importDefault(require("./routes/taskRoutes"));
const assignmentRoutes_1 = __importDefault(require("./routes/assignmentRoutes"));
const attendanceRoutes_1 = __importDefault(require("./routes/attendanceRoutes"));
const wfhRoutes_1 = __importDefault(require("./routes/wfhRoutes"));
const workReportRoutes_1 = __importDefault(require("./routes/workReportRoutes"));
const notificationRoutes_1 = __importDefault(require("./routes/notificationRoutes"));
const auditLogRoutes_1 = __importDefault(require("./routes/auditLogRoutes"));
const chatRoutes_1 = __importDefault(require("./routes/chatRoutes"));
const meetingRoutes_1 = __importDefault(require("./routes/meetingRoutes"));
const goalRoutes_1 = __importDefault(require("./routes/goalRoutes"));
const userManagementRoutes_1 = __importDefault(require("./routes/userManagementRoutes"));
const documentRoutes_1 = __importDefault(require("./routes/documentRoutes"));
const leaveRoutes_1 = __importDefault(require("./routes/leaveRoutes"));
const reportRoutes_1 = __importDefault(require("./routes/reportRoutes"));
const performanceRoutes_1 = __importDefault(require("./routes/performanceRoutes"));
const timesheetRoutes_1 = __importDefault(require("./routes/timesheetRoutes"));
const payrollRoutes_1 = __importDefault(require("./routes/payrollRoutes"));
const expenseRoutes_1 = __importDefault(require("./routes/expenseRoutes"));
const assetRoutes_1 = __importDefault(require("./routes/assetRoutes"));
const onboardingRoutes_1 = __importDefault(require("./routes/onboardingRoutes"));
const offboardingRoutes_1 = __importDefault(require("./routes/offboardingRoutes"));
const monitorRoutes_1 = __importDefault(require("./routes/monitorRoutes"));
const http_1 = require("http");
const socket_1 = require("./socket");
const prisma_1 = __importDefault(require("./utils/prisma"));
const attendanceJob_1 = require("./jobs/attendanceJob");
const app = (0, express_1.default)();
const PORT = process.env.PORT || 5000;
const server = (0, http_1.createServer)(app);
const path_1 = __importDefault(require("path"));
// Initialize Socket.io
(0, socket_1.initSocket)(server);
// Start background jobs
(0, attendanceJob_1.startAttendanceJob)();
// Security: fail fast if JWT secrets are missing in production
if (process.env.NODE_ENV === 'production') {
    if (!process.env.JWT_SECRET || process.env.JWT_SECRET === 'secret') {
        throw new Error('FATAL: JWT_SECRET environment variable is not set or uses insecure default!');
    }
    if (!process.env.JWT_REFRESH_SECRET || process.env.JWT_REFRESH_SECRET === 'refresh_secret') {
        throw new Error('FATAL: JWT_REFRESH_SECRET environment variable is not set or uses insecure default!');
    }
}
// Rate limiters
const authLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 20, // max 20 login/register attempts per 15 min per IP
    message: { error: 'Too many requests from this IP, please try again in 15 minutes.' },
    standardHeaders: true,
    legacyHeaders: false,
});
const apiLimiter = (0, express_rate_limit_1.default)({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 300, // max 300 general API requests per minute per IP
    message: { error: 'Too many requests, please slow down.' },
    standardHeaders: true,
    legacyHeaders: false,
});
// Security headers
app.use((0, helmet_1.default)({
    crossOriginResourcePolicy: { policy: 'cross-origin' } // Allow serving uploaded files
}));
// CORS
app.use((0, cors_1.default)({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    credentials: true
}));
app.use(express_1.default.json({ limit: '2mb' })); // Limit request body size
// Serve uploads directory
app.use('/uploads', express_1.default.static(path_1.default.join(__dirname, '../uploads')));
// Routes
app.use('/api/auth', authLimiter, authRoutes_1.default); // Rate-limited auth routes
app.use('/api', apiLimiter); // General rate limit on all /api routes
app.use('/api/company', companyRoutes_1.default);
app.use('/api/employees', employeeRoutes_1.default);
app.use('/api/departments', departmentRoutes_1.default);
app.use('/api/teams', teamRoutes_1.default);
app.use('/api/projects', projectRoutes_1.default);
app.use('/api/tasks', taskRoutes_1.default);
app.use('/api/assignments', assignmentRoutes_1.default);
app.use('/api/attendance', attendanceRoutes_1.default);
app.use('/api/wfh', wfhRoutes_1.default);
app.use('/api/work-reports', workReportRoutes_1.default);
app.use('/api/notifications', notificationRoutes_1.default);
app.use('/api/audit-logs', auditLogRoutes_1.default);
app.use('/api/chat', chatRoutes_1.default);
app.use('/api/meetings', meetingRoutes_1.default);
app.use('/api/goals', goalRoutes_1.default);
app.use('/api/users', userManagementRoutes_1.default);
app.use('/api/documents', documentRoutes_1.default);
app.use('/api/leaves', leaveRoutes_1.default);
app.use('/api/reports', reportRoutes_1.default);
app.use('/api/performance', performanceRoutes_1.default);
app.use('/api/timesheets', timesheetRoutes_1.default);
app.use('/api/payrolls', payrollRoutes_1.default);
app.use('/api/expenses', expenseRoutes_1.default);
app.use('/api/assets', assetRoutes_1.default);
app.use('/api/onboarding', onboardingRoutes_1.default);
app.use('/api/offboarding', offboardingRoutes_1.default);
app.use('/api/monitor', monitorRoutes_1.default);
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: 'WorkNexus API is running' });
});
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
    // Setup Daily Cleanup Job for Activity Monitor Data (Runs every 24 hours)
    setInterval(async () => {
        try {
            const twoWeeksAgo = new Date();
            twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
            const deletedLogs = await prisma_1.default.activityLog.deleteMany({
                where: { recordedAt: { lt: twoWeeksAgo } }
            });
            const deletedScreenshots = await prisma_1.default.desktopScreenshot.deleteMany({
                where: { takenAt: { lt: twoWeeksAgo } }
            });
            if (deletedLogs.count > 0 || deletedScreenshots.count > 0) {
                console.log(`[Cleanup] Deleted ${deletedLogs.count} old activity logs and ${deletedScreenshots.count} old screenshots.`);
            }
        }
        catch (err) {
            console.error('[Cleanup] Error deleting old monitor data:', err);
        }
    }, 24 * 60 * 60 * 1000);
});
//# sourceMappingURL=index.js.map