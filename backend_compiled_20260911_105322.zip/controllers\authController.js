"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.login = exports.registerCompany = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const prisma_1 = __importDefault(require("../utils/prisma"));
const jwt_1 = require("../utils/jwt");
// ─── REGISTER (creates Company + COMPANY_ADMIN user) ─────────────────────────
const registerCompany = async (req, res) => {
    try {
        const { companyName, firstName, lastName, email, password } = req.body;
        const existingUser = await prisma_1.default.user.findFirst({ where: { email } });
        if (existingUser)
            return res.status(400).json({ error: 'Email already in use' });
        const passwordHash = await bcrypt_1.default.hash(password, 10);
        const result = await prisma_1.default.$transaction(async (tx) => {
            const company = await tx.company.create({
                data: {
                    name: companyName,
                    slug: companyName.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
                    email,
                    workingDays: ['MON', 'TUE', 'WED', 'THU', 'FRI'],
                },
            });
            const user = await tx.user.create({
                data: { companyId: company.id, firstName, lastName, email, passwordHash },
            });
            // Ensure COMPANY_ADMIN role exists
            let role = await tx.role.findFirst({ where: { name: 'COMPANY_ADMIN' } });
            if (!role) {
                role = await tx.role.create({ data: { name: 'COMPANY_ADMIN', description: 'Company Administrator' } });
            }
            await tx.userRole.create({ data: { userId: user.id, roleId: role.id, companyId: company.id } });
            return { company, user, roleName: role.name };
        });
        const tokens = (0, jwt_1.generateTokens)(result.user.id, result.company.id, result.roleName);
        res.status(201).json({
            message: 'Company and admin registered successfully',
            user: {
                id: result.user.id,
                email: result.user.email,
                firstName: result.user.firstName,
                companyId: result.company.id,
                role: result.roleName,
            },
            company: { id: result.company.id, name: result.company.name },
            tokens,
        });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error during registration' });
    }
};
exports.registerCompany = registerCompany;
// ─── LOGIN (returns role in JWT) ─────────────────────────────────────────────
const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await prisma_1.default.user.findFirst({
            where: { email, isDeleted: false },
            include: {
                userRoles: { include: { role: true }, take: 1 },
                company: true
            },
        });
        if (!user)
            return res.status(401).json({ error: 'Invalid credentials' });
        const isValid = user.passwordHash
            ? await bcrypt_1.default.compare(password, user.passwordHash)
            : false;
        if (!isValid)
            return res.status(401).json({ error: 'Invalid credentials' });
        if (!user.companyId)
            return res.status(500).json({ error: 'User has no associated company' });
        if (user.status !== 'ACTIVE') {
            return res.status(403).json({ error: 'Your account has been suspended. Please contact your company administrator.' });
        }
        const roleName = user.userRoles[0]?.role?.name ?? 'EMPLOYEE';
        const isSuperAdmin = roleName === 'SUPER_ADMIN';
        const tokens = (0, jwt_1.generateTokens)(user.id, user.companyId, roleName, isSuperAdmin);
        await prisma_1.default.refreshToken.create({
            data: {
                userId: user.id,
                tokenHash: await bcrypt_1.default.hash(tokens.refreshToken, 10),
                expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            },
        });
        await prisma_1.default.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
        res.json({
            message: 'Login successful',
            user: {
                id: user.id,
                email: user.email,
                firstName: user.firstName,
                companyId: user.companyId,
                companyName: user.company?.name,
                logoUrl: user.company?.logoUrl,
                role: roleName,
                isSuperAdmin,
            },
            tokens,
        });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error during login' });
    }
};
exports.login = login;
//# sourceMappingURL=authController.js.map