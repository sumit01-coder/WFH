import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getOffboardingTasks: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createOffboardingTask: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateOffboardingTaskStatus: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=offboardingController.d.ts.map