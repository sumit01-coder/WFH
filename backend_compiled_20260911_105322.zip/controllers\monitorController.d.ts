import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const logActivity: (req: AuthRequest, res: Response) => Promise<void>;
export declare const uploadScreenshot: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getActivityLogs: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getScreenshots: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=monitorController.d.ts.map