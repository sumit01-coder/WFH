import { Request, Response } from 'express';
export declare const getGoals: (req: Request, res: Response) => Promise<void>;
export declare const updateGoalProgress: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=goalController.d.ts.map