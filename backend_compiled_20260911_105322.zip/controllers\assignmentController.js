"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAssignment = exports.getAssignments = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getAssignments = async (req, res) => {
    try {
        const { companyId, assignedToId } = req.query;
        const assignments = await prisma_1.default.assignment.findMany({
            where: { companyId: String(companyId), assignedToId: String(assignedToId) },
            orderBy: { createdAt: 'desc' }
        });
        res.json(assignments);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching assignments' });
    }
};
exports.getAssignments = getAssignments;
const createAssignment = async (req, res) => {
    try {
        const { companyId, projectId, title, description, instructions, assignedToId, assignedById, dueDate } = req.body;
        const assignment = await prisma_1.default.assignment.create({
            data: {
                companyId, projectId, title, description, instructions, assignedToId, assignedById,
                dueDate: dueDate ? new Date(dueDate) : null
            }
        });
        res.status(201).json(assignment);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error creating assignment' });
    }
};
exports.createAssignment = createAssignment;
//# sourceMappingURL=assignmentController.js.map