"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const expenseController_1 = require("../controllers/expenseController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', expenseController_1.getExpenses);
router.post('/', expenseController_1.submitExpense);
router.put('/:id/status', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'), expenseController_1.updateExpenseStatus);
exports.default = router;
//# sourceMappingURL=expenseRoutes.js.map