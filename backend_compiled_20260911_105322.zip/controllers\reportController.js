"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reviewWorkReport = exports.getWorkReports = exports.submitWorkReport = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const submitWorkReport = async (req, res) => {
    try {
        const { companyId, userId } = req.user;
        const { date, completedWork, wip, blockers, tomorrowPlan, hoursWorked } = req.body;
        const report = await prisma_1.default.workReport.create({
            data: {
                companyId,
                userId,
                date: new Date(date),
                completedWork,
                wip,
                blockers,
                tomorrowPlan,
                hoursWorked,
                status: 'SUBMITTED'
            },
            include: {
                user: { select: { firstName: true, lastName: true } }
            }
        });
        res.status(201).json(report);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to submit work report' });
    }
};
exports.submitWorkReport = submitWorkReport;
const getWorkReports = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        let whereClause = { companyId };
        if (!['HR', 'MANAGER', 'COMPANY_ADMIN', 'SUPER_ADMIN'].includes(role)) {
            whereClause.userId = userId;
        }
        const reports = await prisma_1.default.workReport.findMany({
            where: whereClause,
            include: {
                user: { select: { firstName: true, lastName: true, email: true } },
                reviewedBy: { select: { firstName: true, lastName: true } }
            },
            orderBy: { date: 'desc' }
        });
        res.json(reports);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch work reports' });
    }
};
exports.getWorkReports = getWorkReports;
const reviewWorkReport = async (req, res) => {
    try {
        const { id } = req.params;
        const { reviewComments, status } = req.body;
        const { companyId, userId } = req.user;
        const report = await prisma_1.default.workReport.findFirst({
            where: { id, companyId }
        });
        if (!report) {
            return res.status(404).json({ error: 'Report not found' });
        }
        const updatedReport = await prisma_1.default.workReport.update({
            where: { id },
            data: {
                status: status || 'REVIEWED',
                reviewComments,
                reviewedById: userId,
                reviewedAt: new Date()
            },
            include: {
                user: { select: { firstName: true, lastName: true, email: true } },
                reviewedBy: { select: { firstName: true, lastName: true } }
            }
        });
        res.json(updatedReport);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to review work report' });
    }
};
exports.reviewWorkReport = reviewWorkReport;
//# sourceMappingURL=reportController.js.map