"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getIO = exports.initSocket = void 0;
const socket_io_1 = require("socket.io");
const jwt_1 = require("./utils/jwt");
const prisma_1 = __importDefault(require("./utils/prisma"));
let io;
const initSocket = (server) => {
    io = new socket_io_1.Server(server, {
        cors: {
            origin: process.env.FRONTEND_URL || 'http://localhost:5173',
            methods: ['GET', 'POST']
        }
    });
    // 🔐 Authenticate every socket connection via JWT
    io.use((socket, next) => {
        const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
        if (!token) {
            return next(new Error('Authentication required'));
        }
        try {
            const payload = (0, jwt_1.verifyAccessToken)(token);
            socket.user = payload;
            next();
        }
        catch {
            next(new Error('Invalid or expired token'));
        }
    });
    io.on('connection', (socket) => {
        const user = socket.user;
        console.log(`Socket connected: ${socket.id} (user: ${user?.userId})`);
        // Join personal notification room
        if (user?.userId) {
            socket.join(`user_${user.userId}`);
        }
        // 🔐 Verify room membership before joining
        socket.on('join_room', async (roomId) => {
            try {
                const member = await prisma_1.default.chatMember.findFirst({
                    where: { roomId, userId: user.userId }
                });
                if (!member && !user.isSuperAdmin) {
                    socket.emit('error', { message: 'You are not a member of this room' });
                    return;
                }
                socket.join(roomId);
            }
            catch (err) {
                console.error('join_room error:', err);
            }
        });
        // Leave a specific chat room
        socket.on('leave_room', (roomId) => {
            socket.leave(roomId);
        });
        // Typing indicators — only emit to rooms the socket is actually in
        socket.on('typing_start', ({ roomId, userName }) => {
            if (socket.rooms.has(roomId)) {
                socket.to(roomId).emit('typing_start', { userName });
            }
        });
        socket.on('typing_stop', ({ roomId, userName }) => {
            if (socket.rooms.has(roomId)) {
                socket.to(roomId).emit('typing_stop', { userName });
            }
        });
        // Admin Monitoring
        socket.on('join_admin_monitoring', () => {
            if (['HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'].includes(user?.role)) {
                socket.join(`company_${user.companyId}_monitoring`);
            }
        });
        socket.on('monitoring_update', (data) => {
            if (user?.companyId) {
                socket.to(`company_${user.companyId}_monitoring`).emit('monitoring_update', {
                    userId: user.userId,
                    ...data
                });
            }
        });
        socket.on('disconnect', () => {
            console.log(`Socket disconnected: ${socket.id}`);
        });
    });
    return io;
};
exports.initSocket = initSocket;
const getIO = () => {
    if (!io) {
        throw new Error('Socket.io not initialized');
    }
    return io;
};
exports.getIO = getIO;
//# sourceMappingURL=socket.js.map