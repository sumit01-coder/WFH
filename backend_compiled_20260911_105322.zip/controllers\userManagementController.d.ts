import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const inviteUser: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const listCompanyUsers: (req: AuthRequest, res: Response) => Promise<void>;
export declare const toggleUserAccess: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=userManagementController.d.ts.map