"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAuditLogs = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getAuditLogs = async (req, res) => {
    try {
        const { companyId } = req.query;
        const logs = await prisma_1.default.auditLog.findMany({
            where: { companyId: String(companyId) },
            include: { actor: { select: { firstName: true, lastName: true, email: true } } },
            orderBy: { createdAt: 'desc' },
            take: 100
        });
        res.json(logs);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching audit logs' });
    }
};
exports.getAuditLogs = getAuditLogs;
//# sourceMappingURL=auditLogController.js.map