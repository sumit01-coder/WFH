"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const performanceController_1 = require("../controllers/performanceController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', performanceController_1.getPerformanceRecords);
router.post('/generate', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'), performanceController_1.generatePerformanceRecord);
exports.default = router;
//# sourceMappingURL=performanceRoutes.js.map