"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const assignmentController_1 = require("../controllers/assignmentController");
const router = (0, express_1.Router)();
router.get('/', assignmentController_1.getAssignments);
router.post('/', assignmentController_1.createAssignment);
exports.default = router;
//# sourceMappingURL=assignmentRoutes.js.map