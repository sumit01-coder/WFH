"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const employeeController_1 = require("../controllers/employeeController");
const requireAuth_1 = require("../middleware/requireAuth");
const router = (0, express_1.Router)();
router.get('/', requireAuth_1.requireAuth, employeeController_1.getEmployees);
router.post('/', requireAuth_1.requireAuth, employeeController_1.createEmployee);
router.delete('/:id', requireAuth_1.requireAuth, employeeController_1.deleteEmployee);
exports.default = router;
//# sourceMappingURL=employeeRoutes.js.map