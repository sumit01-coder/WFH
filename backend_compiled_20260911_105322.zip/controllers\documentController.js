"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadDocument = exports.uploadDocument = exports.getDocuments = void 0;
const client_1 = require("@prisma/client");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const prisma = new client_1.PrismaClient();
// Get all documents for the company
const getDocuments = async (req, res) => {
    try {
        const { companyId } = req.user;
        // Fetch files with resourceType 'COMPANY_DOCUMENT'
        const files = await prisma.file.findMany({
            where: {
                companyId,
                resourceType: 'COMPANY_DOCUMENT',
                isDeleted: false
            },
            include: {
                uploadedBy: {
                    select: {
                        firstName: true,
                        lastName: true
                    }
                }
            },
            orderBy: {
                createdAt: 'desc'
            }
        });
        res.json(files);
    }
    catch (error) {
        console.error('Error fetching documents:', error);
        res.status(500).json({ error: 'Failed to fetch documents' });
    }
};
exports.getDocuments = getDocuments;
// Upload a document
const uploadDocument = async (req, res) => {
    try {
        const { companyId, userId } = req.user;
        const file = req.file;
        if (!file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        const newFile = await prisma.file.create({
            data: {
                companyId,
                uploadedById: userId,
                resourceType: 'COMPANY_DOCUMENT',
                resourceId: companyId, // using companyId as resourceId for general docs
                originalName: file.originalname,
                storedName: file.filename,
                filePath: file.path,
                mimeType: file.mimetype,
                sizeBytes: BigInt(file.size),
            }
        });
        const user = await prisma.user.findUnique({
            where: { id: userId },
            select: { firstName: true, lastName: true }
        });
        // We can't easily serialize BigInt to JSON directly, so we convert it to string
        const responseFile = {
            ...newFile,
            sizeBytes: newFile.sizeBytes.toString(),
            uploadedBy: user || { firstName: 'Unknown', lastName: 'User' }
        };
        res.status(201).json(responseFile);
    }
    catch (error) {
        console.error('Error uploading document:', error);
        res.status(500).json({ error: 'Failed to upload document' });
    }
};
exports.uploadDocument = uploadDocument;
// Download a document
const downloadDocument = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { id } = req.params;
        const file = await prisma.file.findFirst({
            where: {
                id,
                companyId,
                isDeleted: false
            }
        });
        if (!file) {
            return res.status(404).json({ error: 'File not found' });
        }
        const filePath = path_1.default.resolve(file.filePath);
        if (!fs_1.default.existsSync(filePath)) {
            return res.status(404).json({ error: 'File not found on disk' });
        }
        res.download(filePath, file.originalName);
    }
    catch (error) {
        console.error('Error downloading document:', error);
        res.status(500).json({ error: 'Failed to download document' });
    }
};
exports.downloadDocument = downloadDocument;
//# sourceMappingURL=documentController.js.map