"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const offboardingController_1 = require("../controllers/offboardingController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', offboardingController_1.getOffboardingTasks);
router.post('/', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'), offboardingController_1.createOffboardingTask);
router.put('/:id', offboardingController_1.updateOffboardingTaskStatus);
exports.default = router;
//# sourceMappingURL=offboardingRoutes.js.map