import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getDepartments: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createDepartment: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=departmentController.d.ts.map