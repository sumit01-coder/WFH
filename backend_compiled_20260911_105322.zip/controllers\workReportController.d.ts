import { Request, Response } from 'express';
export declare const getWorkReports: (req: Request, res: Response) => Promise<void>;
export declare const submitWorkReport: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=workReportController.d.ts.map