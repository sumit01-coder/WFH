"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteTeam = exports.updateTeam = exports.createTeam = exports.getTeams = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getTeams = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { departmentId } = req.query;
        const whereClause = { companyId: String(companyId), isActive: true };
        if (departmentId)
            whereClause.departmentId = String(departmentId);
        const teams = await prisma_1.default.team.findMany({
            where: whereClause,
            include: {
                leader: { select: { firstName: true, lastName: true } },
                department: { select: { name: true } },
                members: { select: { user: { select: { id: true, firstName: true, lastName: true, userRoles: { include: { role: true }, take: 1 } } } } }
            },
            orderBy: { createdAt: 'desc' }
        });
        res.json(teams);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching teams' });
    }
};
exports.getTeams = getTeams;
const rbac_1 = require("../utils/rbac");
const createTeam = async (req, res) => {
    try {
        const { companyId, role: requesterRole } = req.user;
        const { name, description, leaderId, members, departmentId: reqDeptId } = req.body;
        // RBAC check
        if (leaderId) {
            const canAssign = await (0, rbac_1.canModifyUser)(requesterRole, leaderId, true);
            if (!canAssign)
                return res.status(403).json({ error: 'You cannot assign a user of higher role as team leader.' });
        }
        if (members && members.length > 0) {
            for (const memberId of members) {
                const canAssign = await (0, rbac_1.canModifyUser)(requesterRole, memberId, true);
                if (!canAssign)
                    return res.status(403).json({ error: 'You cannot add users of a higher role to this team.' });
            }
        }
        // If no department is provided, we need to create or find a default "General" department
        let departmentId = reqDeptId;
        if (!departmentId) {
            let defaultDept = await prisma_1.default.department.findFirst({ where: { companyId, name: 'General' } });
            if (!defaultDept) {
                defaultDept = await prisma_1.default.department.create({ data: { companyId, name: 'General', description: 'General team department' } });
            }
            departmentId = defaultDept.id;
        }
        const team = await prisma_1.default.team.create({
            data: {
                companyId, departmentId, name, description, leaderId,
                members: {
                    create: (members || []).map((userId) => ({ userId }))
                }
            },
            include: {
                leader: { select: { firstName: true, lastName: true } },
                department: { select: { name: true } },
                members: { select: { user: { select: { id: true, firstName: true, lastName: true, userRoles: { include: { role: true }, take: 1 } } } } }
            }
        });
        // Auto-create chat channel for this team
        const chatMembers = [];
        if (leaderId)
            chatMembers.push({ userId: leaderId });
        if (members && members.length > 0) {
            members.forEach((uid) => {
                if (uid !== leaderId)
                    chatMembers.push({ userId: uid });
            });
        }
        // ensure the creator is in the chat
        if (!chatMembers.some(m => m.userId === req.user.userId)) {
            chatMembers.push({ userId: req.user.userId });
        }
        await prisma_1.default.chatRoom.create({
            data: {
                companyId,
                type: 'TEAM',
                name: `${name} Chat`,
                teamId: team.id,
                createdById: req.user.userId,
                members: {
                    create: chatMembers
                }
            }
        });
        res.status(201).json(team);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error creating team' });
    }
};
exports.createTeam = createTeam;
const updateTeam = async (req, res) => {
    try {
        const { companyId, role: requesterRole } = req.user;
        const teamId = req.params.id;
        const { name, description, leaderId, members, departmentId } = req.body;
        // RBAC check
        if (leaderId) {
            const canAssign = await (0, rbac_1.canModifyUser)(requesterRole, leaderId, true);
            if (!canAssign)
                return res.status(403).json({ error: 'You cannot assign a user of higher role as team leader.' });
        }
        if (members && members.length > 0) {
            for (const memberId of members) {
                const canAssign = await (0, rbac_1.canModifyUser)(requesterRole, memberId, true);
                if (!canAssign)
                    return res.status(403).json({ error: 'You cannot add users of a higher role to this team.' });
            }
        }
        // Verify team belongs to company
        const existingTeam = await prisma_1.default.team.findFirst({
            where: { id: teamId, companyId: String(companyId) }
        });
        if (!existingTeam) {
            return res.status(404).json({ error: 'Team not found' });
        }
        // Prepare update data
        const updateData = {};
        if (name !== undefined)
            updateData.name = name;
        if (description !== undefined)
            updateData.description = description;
        if (leaderId !== undefined)
            updateData.leaderId = leaderId;
        if (departmentId !== undefined)
            updateData.departmentId = departmentId;
        // Handle member updates (delete existing, create new)
        if (members !== undefined) {
            await prisma_1.default.teamMember.deleteMany({ where: { teamId } });
            updateData.members = {
                create: members.map((userId) => ({ userId }))
            };
        }
        const updatedTeam = await prisma_1.default.team.update({
            where: { id: teamId },
            data: updateData,
            include: {
                leader: { select: { firstName: true, lastName: true } },
                department: { select: { name: true } },
                members: { select: { user: { select: { id: true, firstName: true, lastName: true, userRoles: { include: { role: true }, take: 1 } } } } }
            }
        });
        res.json(updatedTeam);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error updating team' });
    }
};
exports.updateTeam = updateTeam;
const deleteTeam = async (req, res) => {
    try {
        const { companyId } = req.user;
        const teamId = req.params.id;
        const existingTeam = await prisma_1.default.team.findFirst({
            where: { id: teamId, companyId: String(companyId) }
        });
        if (!existingTeam) {
            return res.status(404).json({ error: 'Team not found' });
        }
        // Delete members first to satisfy foreign key constraints if no cascade
        await prisma_1.default.teamMember.deleteMany({ where: { teamId } });
        await prisma_1.default.team.delete({
            where: { id: teamId }
        });
        res.json({ success: true, message: 'Team deleted successfully' });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error deleting team' });
    }
};
exports.deleteTeam = deleteTeam;
//# sourceMappingURL=teamController.js.map