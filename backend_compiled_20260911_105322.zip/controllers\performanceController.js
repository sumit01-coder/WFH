"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generatePerformanceRecord = exports.getPerformanceRecords = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getPerformanceRecords = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        let whereClause = { companyId };
        // If regular employee, only show their own records
        if (!['HR', 'MANAGER', 'COMPANY_ADMIN', 'SUPER_ADMIN'].includes(role)) {
            whereClause.userId = userId;
        }
        const records = await prisma_1.default.performanceRecord.findMany({
            where: whereClause,
            include: {
                user: {
                    select: {
                        firstName: true,
                        lastName: true,
                        email: true
                    }
                }
            },
            orderBy: { periodStart: 'desc' }
        });
        res.json(records);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch performance records' });
    }
};
exports.getPerformanceRecords = getPerformanceRecords;
const generatePerformanceRecord = async (req, res) => {
    try {
        const { companyId } = req.user;
        const { employeeId, period, periodStart, periodEnd } = req.body;
        // In a real system, this would query the Tasks, Attendance, and WorkReports tables to compute.
        // For now, we will generate a mock computed record for demonstration purposes.
        const start = new Date(periodStart);
        const end = new Date(periodEnd);
        const record = await prisma_1.default.performanceRecord.upsert({
            where: {
                userId_period_periodStart: {
                    userId: employeeId,
                    period,
                    periodStart: start
                }
            },
            update: {
                periodEnd: end,
                tasksCompleted: Math.floor(Math.random() * 20) + 5,
                attendanceDays: 20,
                computedScore: Math.floor(Math.random() * 3) + 7 // 7 to 10
            },
            create: {
                companyId,
                userId: employeeId,
                period,
                periodStart: start,
                periodEnd: end,
                tasksCompleted: Math.floor(Math.random() * 20) + 5,
                attendanceDays: 20,
                computedScore: Math.floor(Math.random() * 3) + 7 // 7 to 10
            },
            include: {
                user: { select: { firstName: true, lastName: true } }
            }
        });
        res.status(201).json(record);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to generate performance record' });
    }
};
exports.generatePerformanceRecord = generatePerformanceRecord;
//# sourceMappingURL=performanceController.js.map