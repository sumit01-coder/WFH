import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getEmployees: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const createEmployee: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteEmployee: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=employeeController.d.ts.map