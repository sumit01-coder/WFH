"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateGoalProgress = exports.getGoals = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getGoals = async (req, res) => {
    try {
        const { companyId, assignedToId } = req.query;
        const goals = await prisma_1.default.goal.findMany({
            where: { companyId: String(companyId), assignedToId: String(assignedToId) },
            orderBy: { endDate: 'asc' }
        });
        res.json(goals);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching goals' });
    }
};
exports.getGoals = getGoals;
const updateGoalProgress = async (req, res) => {
    try {
        const id = req.params['id'];
        const { currentValue } = req.body;
        const updated = await prisma_1.default.goal.update({
            where: { id },
            data: { currentValue: Number(currentValue) }
        });
        res.json(updated);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error updating goal progress' });
    }
};
exports.updateGoalProgress = updateGoalProgress;
//# sourceMappingURL=goalController.js.map