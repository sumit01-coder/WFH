import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getExpenses: (req: AuthRequest, res: Response) => Promise<void>;
export declare const submitExpense: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateExpenseStatus: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=expenseController.d.ts.map