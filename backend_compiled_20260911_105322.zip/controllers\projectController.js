"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateProject = exports.createProject = exports.getProjects = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getProjects = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        const isAdmin = ['SUPER_ADMIN', 'COMPANY_ADMIN', 'HR'].includes(role);
        let whereClause = { companyId, isArchived: false };
        if (!isAdmin) {
            whereClause = {
                ...whereClause,
                OR: [
                    { managerId: userId },
                    { team: { members: { some: { userId } } } }
                ]
            };
        }
        const projects = await prisma_1.default.project.findMany({
            where: whereClause,
            include: { team: { select: { name: true } }, manager: { select: { firstName: true, lastName: true } } }
        });
        res.json(projects);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching projects' });
    }
};
exports.getProjects = getProjects;
const createProject = async (req, res) => {
    try {
        const { name, description, clientName, githubRepo, managerId, teamId, status, priority, startDate, endDate } = req.body;
        const { companyId } = req.user;
        const project = await prisma_1.default.project.create({
            data: {
                companyId, name, description, clientName, githubRepo, managerId, teamId, status, priority,
                startDate: startDate ? new Date(startDate) : null,
                endDate: endDate ? new Date(endDate) : null
            }
        });
        if (managerId && managerId !== req.user.userId) {
            const notification = await prisma_1.default.notification.create({
                data: {
                    companyId,
                    userId: managerId,
                    type: 'PROJECT',
                    title: 'New Project Assigned',
                    body: `You have been assigned as the manager for project: ${name}`,
                    resourceType: 'PROJECT',
                    resourceId: project.id
                }
            });
            try {
                const { getIO } = require('../socket');
                getIO().to(`user_${managerId}`).emit('new_notification', notification);
            }
            catch (err) {
                console.error('Failed to emit realtime notification:', err);
            }
        }
        res.status(201).json(project);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error creating project' });
    }
};
exports.createProject = createProject;
const updateProject = async (req, res) => {
    try {
        const id = req.params['id'];
        const { name, description, clientName, githubRepo, managerId, teamId, status, priority, startDate, endDate } = req.body;
        const { companyId, userId } = req.user;
        const existingProject = await prisma_1.default.project.findUnique({ where: { id, companyId } });
        if (!existingProject) {
            return res.status(404).json({ error: 'Project not found' });
        }
        const updatedProject = await prisma_1.default.$transaction(async (tx) => {
            const project = await tx.project.update({
                where: { id },
                data: {
                    name, description, clientName, githubRepo, managerId, teamId, status, priority,
                    startDate: startDate ? new Date(startDate) : null,
                    endDate: endDate ? new Date(endDate) : null
                }
            });
            await tx.auditLog.create({
                data: {
                    companyId,
                    actorId: userId,
                    action: 'UPDATE_PROJECT',
                    resourceType: 'PROJECT',
                    resourceId: id,
                    oldData: existingProject,
                    newData: project
                }
            });
            return project;
        });
        res.json(updatedProject);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error updating project' });
    }
};
exports.updateProject = updateProject;
//# sourceMappingURL=projectController.js.map