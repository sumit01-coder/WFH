"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllCompanies = exports.uploadCompanyLogo = exports.updateCompanyProfile = exports.getCompanyProfile = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getCompanyProfile = async (req, res) => {
    try {
        // Use companyId from JWT — only allow fetching own company (unless SuperAdmin)
        const companyId = req.user.isSuperAdmin
            ? req.params['companyId']
            : req.user.companyId;
        const company = await prisma_1.default.company.findUnique({ where: { id: companyId } });
        if (!company)
            return res.status(404).json({ error: 'Company not found' });
        res.json(company);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching company' });
    }
};
exports.getCompanyProfile = getCompanyProfile;
const updateCompanyProfile = async (req, res) => {
    try {
        // Always use JWT companyId — prevents IDOR / cross-tenant edits
        const companyId = req.user.isSuperAdmin
            ? req.params['companyId']
            : req.user.companyId;
        const { name, address, phone, website, email, workingDays, workingHoursStart, workingHoursEnd, breakStart, breakEnd, timezone } = req.body;
        const updateData = { name, address, phone, website, email, timezone };
        if (workingDays)
            updateData.workingDays = workingDays;
        if (workingHoursStart)
            updateData.workingHoursStart = new Date(`1970-01-01T${workingHoursStart}:00.000Z`);
        if (workingHoursEnd)
            updateData.workingHoursEnd = new Date(`1970-01-01T${workingHoursEnd}:00.000Z`);
        // Lunch break — allow clearing by passing empty string
        if (breakStart) {
            updateData.breakStart = new Date(`1970-01-01T${breakStart}:00.000Z`);
        }
        else if (breakStart === '') {
            updateData.breakStart = null;
        }
        if (breakEnd) {
            updateData.breakEnd = new Date(`1970-01-01T${breakEnd}:00.000Z`);
        }
        else if (breakEnd === '') {
            updateData.breakEnd = null;
        }
        const updated = await prisma_1.default.company.update({
            where: { id: companyId },
            data: updateData
        });
        res.json(updated);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error updating company' });
    }
};
exports.updateCompanyProfile = updateCompanyProfile;
const uploadCompanyLogo = async (req, res) => {
    try {
        // Always use JWT companyId — prevents IDOR
        const companyId = req.user.isSuperAdmin
            ? req.params['companyId']
            : req.user.companyId;
        if (!req.file)
            return res.status(400).json({ error: 'No image uploaded' });
        // Assuming the server is running on the same domain and we just store the relative path
        const logoUrl = `/uploads/${req.file.filename}`;
        const updated = await prisma_1.default.company.update({
            where: { id: companyId },
            data: { logoUrl }
        });
        res.json({ message: 'Logo uploaded successfully', logoUrl: updated.logoUrl });
    }
    catch (error) {
        console.error('Logo upload error:', error);
        res.status(500).json({ error: 'Server error uploading logo' });
    }
};
exports.uploadCompanyLogo = uploadCompanyLogo;
const getAllCompanies = async (req, res) => {
    try {
        const companies = await prisma_1.default.company.findMany({
            include: {
                _count: {
                    select: { users: true }
                },
                users: {
                    where: {
                        userRoles: {
                            some: {
                                role: {
                                    name: 'COMPANY_ADMIN'
                                }
                            }
                        }
                    },
                    select: {
                        id: true,
                        firstName: true,
                        lastName: true,
                        email: true,
                        phone: true
                    }
                }
            },
            orderBy: {
                createdAt: 'desc'
            }
        });
        const formattedCompanies = companies.map(company => ({
            id: company.id,
            name: company.name,
            slug: company.slug,
            logoUrl: company.logoUrl,
            subscriptionPlan: company.subscriptionPlan,
            createdAt: company.createdAt,
            employeeCount: company._count.users,
            email: company.email,
            phone: company.phone,
            address: company.address,
            website: company.website,
            isActive: company.isActive,
            timezone: company.timezone,
            workingDays: company.workingDays,
            workingHoursStart: company.workingHoursStart,
            workingHoursEnd: company.workingHoursEnd,
            admin: company.users[0] || null
        }));
        res.json(formattedCompanies);
    }
    catch (error) {
        console.error('Error fetching all companies:', error);
        res.status(500).json({ error: 'Server error fetching all companies' });
    }
};
exports.getAllCompanies = getAllCompanies;
//# sourceMappingURL=companyController.js.map