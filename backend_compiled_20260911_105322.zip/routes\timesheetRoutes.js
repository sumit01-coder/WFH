"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const timesheetController_1 = require("../controllers/timesheetController");
const requireAuth_1 = require("../middleware/requireAuth");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/', timesheetController_1.getTimesheets);
router.post('/', timesheetController_1.createTimesheetEntry);
exports.default = router;
//# sourceMappingURL=timesheetRoutes.js.map