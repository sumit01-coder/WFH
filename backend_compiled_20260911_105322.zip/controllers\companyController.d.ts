import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getCompanyProfile: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateCompanyProfile: (req: AuthRequest, res: Response) => Promise<void>;
export declare const uploadCompanyLogo: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getAllCompanies: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=companyController.d.ts.map