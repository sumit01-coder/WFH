"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const leaveController_1 = require("../controllers/leaveController");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const router = (0, express_1.Router)();
router.use(requireAuth_1.requireAuth);
router.get('/balances', leaveController_1.getLeaveBalances);
router.put('/balances/bulk', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'), leaveController_1.updateBulkLeaveBalances);
router.put('/balances', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'), leaveController_1.updateLeaveBalance);
router.get('/', leaveController_1.getLeaveRequests);
router.post('/', leaveController_1.createLeaveRequest);
router.put('/:id/status', (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN', 'MANAGER'), leaveController_1.updateLeaveStatus);
exports.default = router;
//# sourceMappingURL=leaveRoutes.js.map