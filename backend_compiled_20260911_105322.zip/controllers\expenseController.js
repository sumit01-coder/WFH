"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateExpenseStatus = exports.submitExpense = exports.getExpenses = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getExpenses = async (req, res) => {
    try {
        const { companyId, userId, role } = req.user;
        let whereClause = { companyId };
        if (!['HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'].includes(role)) {
            whereClause.userId = userId;
        }
        const expenses = await prisma_1.default.expense.findMany({
            where: whereClause,
            include: {
                user: { select: { firstName: true, lastName: true, email: true } }
            },
            orderBy: { createdAt: 'desc' }
        });
        res.json(expenses);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch expenses' });
    }
};
exports.getExpenses = getExpenses;
const submitExpense = async (req, res) => {
    try {
        const { companyId, userId } = req.user;
        const { amount, category, description, receiptUrl } = req.body;
        if (!amount || !category || !description) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const expense = await prisma_1.default.expense.create({
            data: {
                companyId,
                userId,
                amount: Number(amount),
                category,
                description,
                receiptUrl,
                status: 'PENDING'
            },
            include: {
                user: { select: { firstName: true, lastName: true } }
            }
        });
        res.status(201).json(expense);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to submit expense' });
    }
};
exports.submitExpense = submitExpense;
const rbac_1 = require("../utils/rbac");
const updateExpenseStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const { companyId, role: requesterRole } = req.user;
        if (!['APPROVED', 'REJECTED'].includes(status)) {
            return res.status(400).json({ error: 'Invalid status' });
        }
        const expenseRequest = await prisma_1.default.expense.findFirst({
            where: { id, companyId }
        });
        if (!expenseRequest) {
            return res.status(404).json({ error: 'Expense request not found' });
        }
        const canAssign = await (0, rbac_1.canModifyUser)(requesterRole, expenseRequest.userId, false);
        if (!canAssign) {
            return res.status(403).json({ error: 'You do not have permission to approve/reject expenses for this user.' });
        }
        const expense = await prisma_1.default.expense.update({
            where: { id, companyId },
            data: { status }
        });
        res.json(expense);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to update expense status' });
    }
};
exports.updateExpenseStatus = updateExpenseStatus;
//# sourceMappingURL=expenseController.js.map