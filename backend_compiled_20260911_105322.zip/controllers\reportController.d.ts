import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const submitWorkReport: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getWorkReports: (req: AuthRequest, res: Response) => Promise<void>;
export declare const reviewWorkReport: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=reportController.d.ts.map