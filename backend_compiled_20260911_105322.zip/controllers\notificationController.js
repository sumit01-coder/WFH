"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.markAllAsRead = exports.markAsRead = exports.getUnreadCount = exports.getNotifications = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getNotifications = async (req, res) => {
    try {
        const { userId, companyId } = req.user;
        const notifications = await prisma_1.default.notification.findMany({
            where: { companyId, userId },
            orderBy: { createdAt: 'desc' },
            take: 50
        });
        res.json(notifications);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching notifications' });
    }
};
exports.getNotifications = getNotifications;
const getUnreadCount = async (req, res) => {
    try {
        const { userId, companyId } = req.user;
        const count = await prisma_1.default.notification.count({
            where: { companyId, userId, isRead: false }
        });
        res.json({ count });
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching unread count' });
    }
};
exports.getUnreadCount = getUnreadCount;
const markAsRead = async (req, res) => {
    try {
        const id = req.params['id'];
        const updated = await prisma_1.default.notification.update({
            where: { id },
            data: { isRead: true }
        });
        res.json(updated);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error updating notification' });
    }
};
exports.markAsRead = markAsRead;
const markAllAsRead = async (req, res) => {
    try {
        const { userId, companyId } = req.user;
        await prisma_1.default.notification.updateMany({
            where: { userId, companyId },
            data: { isRead: true }
        });
        res.json({ message: 'All notifications marked as read' });
    }
    catch (error) {
        res.status(500).json({ error: 'Server error updating notifications' });
    }
};
exports.markAllAsRead = markAllAsRead;
//# sourceMappingURL=notificationController.js.map