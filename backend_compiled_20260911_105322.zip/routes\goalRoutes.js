"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const goalController_1 = require("../controllers/goalController");
const router = (0, express_1.Router)();
router.get('/', goalController_1.getGoals);
router.patch('/:id/progress', goalController_1.updateGoalProgress);
exports.default = router;
//# sourceMappingURL=goalRoutes.js.map