"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDepartment = exports.getDepartments = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getDepartments = async (req, res) => {
    try {
        const { companyId } = req.user;
        const departments = await prisma_1.default.department.findMany({
            where: { companyId, isActive: true }
        });
        res.json(departments);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching departments' });
    }
};
exports.getDepartments = getDepartments;
const rbac_1 = require("../utils/rbac");
const createDepartment = async (req, res) => {
    try {
        const { companyId, role: requesterRole } = req.user;
        const { name, description, headId } = req.body;
        if (headId) {
            const canAssign = await (0, rbac_1.canModifyUser)(requesterRole, headId, true);
            if (!canAssign)
                return res.status(403).json({ error: 'You cannot assign a user of higher role as department head.' });
        }
        const department = await prisma_1.default.department.create({
            data: { companyId, name, description, headId }
        });
        res.status(201).json(department);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error creating department' });
    }
};
exports.createDepartment = createDepartment;
//# sourceMappingURL=departmentController.js.map