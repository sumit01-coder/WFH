import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getWfhRequests: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createWfhRequest: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateWfhStatus: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=wfhController.d.ts.map