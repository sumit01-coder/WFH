export declare const startAttendanceJob: () => void;
//# sourceMappingURL=attendanceJob.d.ts.map