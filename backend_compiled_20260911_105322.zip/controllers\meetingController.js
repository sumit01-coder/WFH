"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMeeting = exports.getMeetings = void 0;
const prisma_1 = __importDefault(require("../utils/prisma"));
const getMeetings = async (req, res) => {
    try {
        const { companyId, userId } = req.user;
        const meetings = await prisma_1.default.meeting.findMany({
            where: {
                companyId,
                participants: { some: { userId } }
            },
            include: {
                organizer: { select: { firstName: true, lastName: true } },
                participants: { select: { userId: true, rsvp: true } }
            },
            orderBy: { startAt: 'asc' }
        });
        res.json(meetings);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error fetching meetings' });
    }
};
exports.getMeetings = getMeetings;
const createMeeting = async (req, res) => {
    try {
        const { title, description, startAt, endAt, location, participants } = req.body;
        const { companyId, userId: organizerId } = req.user;
        // Ensure the organizer is also included in the participants array
        const participantIds = new Set(participants || []);
        participantIds.add(organizerId);
        const meeting = await prisma_1.default.meeting.create({
            data: {
                companyId, title, description, organizerId, location,
                startAt: new Date(startAt),
                endAt: new Date(endAt),
                participants: {
                    create: Array.from(participantIds).map((uid) => ({ userId: uid }))
                }
            },
            include: {
                organizer: { select: { firstName: true, lastName: true } },
                participants: { select: { userId: true, rsvp: true } }
            }
        });
        res.status(201).json(meeting);
    }
    catch (error) {
        res.status(500).json({ error: 'Server error creating meeting' });
    }
};
exports.createMeeting = createMeeting;
//# sourceMappingURL=meetingController.js.map