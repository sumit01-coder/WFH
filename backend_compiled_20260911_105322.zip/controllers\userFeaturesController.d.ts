import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
/**
 * GET /api/users/me/features
 * Returns which sidebar features are active for the current employee
 * based on what HR/Manager has assigned/created for them.
 */
export declare const getMyFeatures: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=userFeaturesController.d.ts.map