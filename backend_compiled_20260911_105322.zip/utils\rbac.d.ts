export declare const ROLE_RANKS: Record<string, number>;
export declare const getRoleRank: (roleName: string) => number;
/**
 * Gets the highest rank of a given user based on their UserRoles.
 * @param userId The ID of the user to check
 * @returns The highest numeric rank of the user's roles
 */
export declare const getUserMaxRank: (userId: string) => Promise<number>;
/**
 * Checks if the requester has permission to modify/assign the target user based on strict vertical hierarchy.
 * @param requesterRole The role name of the user performing the action (e.g., 'HR', 'COMPANY_ADMIN')
 * @param targetUserId The ID of the user being acted upon
 * @param allowEqual If true, users of equal rank can modify each other (default: false)
 * @returns true if permitted, false if the target user has an equal or higher rank
 */
export declare const canModifyUser: (requesterRole: string, targetUserId: string, allowEqual?: boolean) => Promise<boolean>;
//# sourceMappingURL=rbac.d.ts.map