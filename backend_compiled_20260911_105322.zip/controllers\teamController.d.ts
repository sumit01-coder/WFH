import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getTeams: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createTeam: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateTeam: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteTeam: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=teamController.d.ts.map