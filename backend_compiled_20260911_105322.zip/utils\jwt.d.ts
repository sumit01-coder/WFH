export interface TokenPayload {
    userId: string;
    companyId: string;
    role: string;
    isSuperAdmin?: boolean;
}
export declare const generateTokens: (userId: string, companyId: string, role: string, isSuperAdmin?: boolean) => {
    accessToken: string;
    refreshToken: string;
};
export declare const verifyAccessToken: (token: string) => TokenPayload;
export declare const verifyRefreshToken: (token: string) => TokenPayload;
//# sourceMappingURL=jwt.d.ts.map