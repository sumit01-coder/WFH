import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getPayrolls: (req: AuthRequest, res: Response) => Promise<void>;
export declare const generatePayroll: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const markPayrollPaid: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=payrollController.d.ts.map