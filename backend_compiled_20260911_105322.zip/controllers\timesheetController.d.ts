import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getTimesheets: (req: AuthRequest, res: Response) => Promise<void>;
export declare const createTimesheetEntry: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=timesheetController.d.ts.map