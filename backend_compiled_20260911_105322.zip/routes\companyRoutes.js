"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const companyController_1 = require("../controllers/companyController");
const router = (0, express_1.Router)();
// Configure multer for logo uploads
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path_1.default.join(__dirname, '../../uploads'));
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path_1.default.extname(file.originalname));
    }
});
const upload = (0, multer_1.default)({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        }
        else {
            cb(new Error('Only images are allowed'));
        }
    }
});
// Super admin only — get all companies
router.get('/', requireAuth_1.requireAuth, (0, requireRole_1.requireRole)('SUPER_ADMIN'), companyController_1.getAllCompanies);
// Any authenticated user can read their own company — ownership enforced in controller
router.get('/:companyId', requireAuth_1.requireAuth, companyController_1.getCompanyProfile);
// Only Company Admin or Super Admin can update company profile
router.put('/:companyId', requireAuth_1.requireAuth, (0, requireRole_1.requireRole)('COMPANY_ADMIN', 'HR', 'SUPER_ADMIN'), companyController_1.updateCompanyProfile);
// Only Company Admin or Super Admin can upload logo
router.post('/:companyId/logo', requireAuth_1.requireAuth, (0, requireRole_1.requireRole)('COMPANY_ADMIN', 'SUPER_ADMIN'), upload.single('logo'), companyController_1.uploadCompanyLogo);
exports.default = router;
//# sourceMappingURL=companyRoutes.js.map