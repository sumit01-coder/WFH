"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const requireAuth_1 = require("../middleware/requireAuth");
const requireRole_1 = require("../middleware/requireRole");
const userManagementController_1 = require("../controllers/userManagementController");
const userFeaturesController_1 = require("../controllers/userFeaturesController");
const router = (0, express_1.Router)();
// Only HR, Company Admin, and Super Admin can invite users
router.post('/invite', requireAuth_1.requireAuth, (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'), userManagementController_1.inviteUser);
// Everyone in the company can see the list of users (to know their colleagues)
router.get('/', requireAuth_1.requireAuth, userManagementController_1.listCompanyUsers);
// Returns which sidebar features/sections are active for the logged-in user
router.get('/me/features', requireAuth_1.requireAuth, userFeaturesController_1.getMyFeatures);
// Toggle user login access (active/suspended)
router.put('/:id/access', requireAuth_1.requireAuth, (0, requireRole_1.requireRole)('HR', 'COMPANY_ADMIN', 'SUPER_ADMIN'), userManagementController_1.toggleUserAccess);
exports.default = router;
//# sourceMappingURL=userManagementRoutes.js.map