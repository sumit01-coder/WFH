import { Response } from 'express';
import { AuthRequest } from '../middleware/requireAuth';
export declare const getDocuments: (req: AuthRequest, res: Response) => Promise<void>;
export declare const uploadDocument: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const downloadDocument: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=documentController.d.ts.map